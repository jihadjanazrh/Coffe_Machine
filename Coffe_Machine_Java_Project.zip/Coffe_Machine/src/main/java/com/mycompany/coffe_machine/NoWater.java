
package com.mycompany.coffe_machine;


public class NoWater extends Exception{

    public NoWater() {
        super("there is no water ");
    }
    
    
}
