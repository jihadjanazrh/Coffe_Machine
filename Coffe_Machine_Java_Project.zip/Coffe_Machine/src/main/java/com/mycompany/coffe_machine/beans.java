package com.mycompany.coffe_machine;

import javax.swing.JOptionPane;

public class beans {
    
    
    private int arabica;
    private int robusta;
    private int capacity;
    private int existingQuantity ;

    public beans(int arabica, int robusta, int capacity, int existingQuantity) {
        this.arabica = arabica;
        this.robusta = robusta;
        this.capacity = capacity;
        this.existingQuantity = existingQuantity;
    }

    public int getArabica() {
        return arabica;
    }

    public void setArabica(int arabica) {
        this.arabica = arabica;
    }

    public int getRobusta() {
        return robusta;
    }

    public void setRobusta(int robusta) {
        this.robusta = robusta;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getExistingQuantity() {
        return existingQuantity;
    }

    public void setExistingQuantity(int existingQuantity) {
        this.existingQuantity = existingQuantity;
    }
    public boolean givecoffe(double i ){
        try{
        if (this.existingQuantity -i <0 )
            throw new CoffeEmptyException();
        else 
            this.existingQuantity -= i;
        }
        catch( CoffeEmptyException ex ){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            return false ;
        }
            return true ;
    }
    public void fullCoffe(){
        this.existingQuantity = this.capacity;
    }
    public String getInfo() {
        return "beans{" + "arabica=" + arabica + ", robusta=" + robusta + '}';
    }
    

}
