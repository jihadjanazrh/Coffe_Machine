package com.mycompany.coffe_machine;

public class grind {
        private int size;
    public grind()
    {
        
    }
    
    public grind(int size)
    {
        this.size=size;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getinfo() {
        return "grind{" + "size=" + size + '}';
    }
    

}
