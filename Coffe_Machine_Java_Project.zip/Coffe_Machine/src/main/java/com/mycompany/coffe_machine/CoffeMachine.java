
package com.mycompany.coffe_machine;

import javax.swing.JOptionPane;

public class CoffeMachine {
     private  WaterTank water ;
    private beans  coffeBeans;
    private  grind grinding ;
    private garbage garb;
  
    public CoffeMachine() {
    }

    public CoffeMachine(WaterTank water, beans coffeBeans, grind grinding, garbage garb) {
        this.water = water;
        this.coffeBeans = coffeBeans;
        this.grinding = grinding;
        this.garb = garb;
    }

    public WaterTank getWater() {
        return water;
    }

    public void setWater(WaterTank water) {
        this.water = water;
    }

    public beans getCoffeBeans() {
        return coffeBeans;
    }

    public void setCoffeBeans(beans coffeBeans) {
        this.coffeBeans = coffeBeans;
    }

    public grind getGrinding() {
        return grinding;
    }

    public void setGrinding(grind grinding) {
        this.grinding = grinding;
    }

    public garbage getGarb() {
        return garb;
    }

    public void setGarb(garbage garb) {
        this.garb = garb;
    }
    public  void Espresso(int size, int grindDegree){
        if (this.getGarb().add(1)&&this.getWater().drain(1)&&this.getCoffeBeans().givecoffe(1)){
        if (size == 1 ){
            this.getCoffeBeans().givecoffe(7);
            this.getWater().drain(30);
            this.getGrinding().setSize(grindDegree);
            this.getGarb().add(37);
            JOptionPane.showMessageDialog(null, "espresso short contain  55 Caffeine and   7 calories ");
            
        }
        else 
        {
            this.getCoffeBeans().givecoffe(14);
            this.getWater().drain(60);
            this.getGrinding().setSize(grindDegree);
            this.getGarb().add(74);
        JOptionPane.showMessageDialog(null, "espresso short contain  121 Caffeine and   9 calories ");
        }
        }
        
    }
public  void americano(int size, int grindDegree){
     if (this.getGarb().add(1)&&this.getWater().drain(1)&&this.getCoffeBeans().givecoffe(1)){
        if (size == 1 ){
            this.getCoffeBeans().givecoffe(7);
            this.getWater().drain(170);
            this.getGrinding().setSize(grindDegree);
            this.getGarb().add(177);
             
     JOptionPane.showMessageDialog(null, "espresso short contain  51 Caffeine and   11 calories ");       
        }
        else 
        {
            this.getCoffeBeans().givecoffe(14);
            this.getWater().drain(220);
            this.getGrinding().setSize(grindDegree);
            this.getGarb().add(234);
        JOptionPane.showMessageDialog(null, "espresso short contain  97 Caffeine and   19 calories ");
        }
     }
    }
    @Override
    public String toString() {
        return "CoffeMachine{" + "water=" + water.getInfo() + ", coffeBeans=" + coffeBeans.getInfo() + ", grinding=" + grinding.getinfo() + ", garb=" + garb + '}';
    }
    
  
   
    
}
