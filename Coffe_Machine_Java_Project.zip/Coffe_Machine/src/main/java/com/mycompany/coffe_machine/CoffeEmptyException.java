
package com.mycompany.coffe_machine;


public class CoffeEmptyException extends Exception{

    public CoffeEmptyException() {
        super("there is no coffe \n pleas add coffe ");
    }
    
    
}
