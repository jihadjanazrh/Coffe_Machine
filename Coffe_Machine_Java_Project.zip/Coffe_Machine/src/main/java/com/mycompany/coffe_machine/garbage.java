
package com.mycompany.coffe_machine;

import javax.swing.JOptionPane;

public class garbage {
    private  int exsist ;
    private int capacity ;
  

    public garbage(int exist, int capacity) {
        this.exsist = exist;
        this.capacity = capacity;
    }

    public garbage() {
    }

    public int getExist() {
        return exsist;
    }

    public void setExist(int exist) {
        this.exsist = exist;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    public boolean add( double garbage ){
        try{
            if (this.exsist + garbage > this.capacity )
                throw  new fullGarbage();
            else 
                this.exsist += garbage;
            
            
             }
        catch(fullGarbage ex ){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            return false ;
        }
        return true ;
    }
}
