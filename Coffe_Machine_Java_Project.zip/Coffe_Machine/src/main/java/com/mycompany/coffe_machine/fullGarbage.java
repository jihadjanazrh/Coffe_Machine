
package com.mycompany.coffe_machine;

public class fullGarbage  extends  Exception{

    public fullGarbage() {
        super( "full garbage ");
    }
    
}
