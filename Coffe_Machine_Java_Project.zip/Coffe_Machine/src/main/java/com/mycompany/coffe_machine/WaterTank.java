package com.mycompany.coffe_machine;

import javax.swing.JOptionPane;

public class WaterTank {
    private int capacity;
    private int level;

    public WaterTank(int water) {
        
    }
    
    public WaterTank()
    {
        
    }

    public WaterTank(int capacity, int level) {
        this.capacity = capacity;
        this.level = level;
    }

 
    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    

    
    public void fill (int water)
    {  
        this.level =capacity;
    }
    public boolean drain(float water)
            
    {
         try {
             if ((this.level -water) < 0 )
                 throw new NoWater();
             else this.level-=water;
        } catch (NoWater e) {
             JOptionPane.showMessageDialog(null, e.getMessage());         
             return false;
        }
        return true ;
      
    }

    public String getInfo() {
        return "WaterTank{" + "level=" + this.level + '}'+"capacity equal ="+" "+this.capacity;

    }  
}
    

